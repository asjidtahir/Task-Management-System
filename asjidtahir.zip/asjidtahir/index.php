<?php
require 'authentication.php'; // admin authentication check 

// auth check
if(isset($_SESSION['admin_id'])){
  $user_id = $_SESSION['admin_id'];
  $user_name = $_SESSION['admin_name'];
  $security_key = $_SESSION['security_key'];
  if ($user_id != NULL && $security_key != NULL) {
    header('Location: task-info.php');
  }
}

if(isset($_POST['login_btn'])){
 $info = $obj_admin->admin_login_check($_POST);
}

$page_name = "Login";
include("include/login_header.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Task Management System - Login</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles.css"> 
  <style>
	/* Body styles */
body {
    background-image: url('AJJI.jpg'); /* Replace with the path to your background image */
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    color: #333;
    min-height: 100vh;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  /* Header styles */
  header {
    text-align: center;
    margin-bottom: 5px;
    background-color: rgba(0, 0, 0, 0.5);
    padding: 20px;
    border-radius: 10px;
  }
  
  header h1 {
    font-size: 36px;
    color: #fff;
    margin: 0;
    padding: 0;
  }
  
  header p {
    font-size: 18px;
    color: #fff;
    opacity: 0.8;
    margin: 0;
    padding: 0;
  }
  
  /* Card styles */
  .card {
    border: none;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  .card-title {
    color: #333;
  }
  
  /* Form styles */
  .form-custom-login {
    padding: 20px;
  }
  
  .form-control {
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  
  /* Button styles */
  .btn-info {
    background-color: #4a90e2;
    border: none;
  }
  
  .btn-info:hover {
    background-color: #357ebd;
  }
  
  /* Footer styles */
  footer {
    margin-top: 50px;
    padding: 20px 0;
    background-color: rgba(0, 0, 0, 0.1);
    color: #777;
  }
  
	</style>

  <!-- Add your custom styles here -->
</head>
<body class="bg-light">

<header>
  <h1 class="display-4">Task Management System</h1>
  <p class="lead">Efficiently Manage Your Employee Tasks</p>
</header>

<div class="container mt-5">
  <div class="row justify-content-end">
    <div class="col-md-6">
      <div class="card p-4">
        <div class="card-body">
          <h2 class="card-title text-center mb-4">Employee Task Management System</h2>

          <?php if(isset($info)){ ?>
          <div class="alert alert-danger"><?php echo $info; ?></div>
          <?php } ?>

          <form class="form-custom-login" action="" method="POST">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Username" name="username" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" placeholder="Password" name="admin_password" required>
            </div>
            <button type="submit" name="login_btn" class="btn btn-info btn-block">Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<footer class="text-center mt-5">
  <p>&copy; <?php echo date("Y"); ?> Employee Task Management System. All rights reserved.</p>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
